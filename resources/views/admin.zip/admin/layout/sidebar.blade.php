<div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a  href="javascript:void()" aria-expanded="false">
							<i class="flaticon-dashboard-1"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                   </li>
            
                   
                    <!-- <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
						<i class="flaticon-app"></i>
							<span class="nav-text">User Management</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="{{url('/adduser')}}">Add User</a></li>
                            <li><a href="{{url('/listuser')}}">View User</a></li>
                        </ul>
                    </li> -->
                     <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-table"></i>
							<span class="nav-text">Coach Menu</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="{{url('/addtrainner')}}">Add Coach</a></li>
                            <li><a href="{{url('/listtrainner')}}">View Coach</a></li>
                        </ul>
                    </li>
                       <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
								<i class="flaticon-network"></i>
							<span class="nav-text">Student Menu</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="{{url('/addstudent')}}">Add Student</a></li>
                            <li><a href="{{url('/liststudent')}}">View Student</a></li>
                        </ul>
                    </li> 

                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-bar-chart-1"></i>
							<span class="nav-text">category Menu</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="{{url('/addcategory')}}">Add category</a></li>
                            <li><a href="{{url('/listcategory')}}">View category</a></li>
                        </ul>
                    </li>
                     <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-bar-chart-1"></i>
							<span class="nav-text">Subcategory Menu</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="{{url('/addsubcategory')}}">Add Subcategory</a></li>
                            <li><a href="{{url('/listsubcategory')}}">View Subcategory</a></li>
                        </ul>
                    </li>
                     <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
								<i class="flaticon-network"></i>
							<span class="nav-text">Course Menu</span>
						</a>
                        <ul aria-expanded="false">
                            <li><a href="{{url('/addcourse')}}">Add Course</a></li>
                            <li><a href="{{url('/listcourse')}}">View Course</a></li>
                        </ul>
                    </li>
                     <li><a href="javascript:void()" aria-expanded="false">
							  <a href="{{ route('logout') }}"> logout</a> 
						</a>
                    </li>  
               
                   
                </ul>
            
				<div class="plus-box">
					<p class="fs-13 font-w300 mb-4">Organize your menus through button bellow</p>
					<a class="btn bg-white text-black btn-rounded d-block" href="javascript:;">+Add Menus</a>
				</div>
				<div class="copyright">
					<p class="fs-14 font-w200"><strong class="font-w400"></strong> </strong> </p>
					<p><span class="heart"></span> </p>
				</div>
			</div>
        </div>