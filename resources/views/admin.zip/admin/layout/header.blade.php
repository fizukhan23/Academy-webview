<head>
     <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="Academi App" >
    
  
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Academi App" >
    <meta property="og:title" content="Academi App" />
    <meta property="og:description" content="Academi App" >
    <meta property="og:image" content="social-image.png" >
    <meta name="format-detection" content="telephone=no">
    <title>Academi App</title>
    <!-- Favicon icon -->
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="{{asset('panel/vendor/bootstrap-select/dist/css/bootstrap-select.min.css')}}" rel="stylesheet">
    <link href="{{asset('panel/css/style.css')}}" rel="stylesheet">
	<link href="{{asset('panel/cdn.lineicons.com/2.0/LineIcons.css')}}" rel="stylesheet">
	<style>
		.head>tr>th{
             margin:20px;     
		}
</style>
</head>