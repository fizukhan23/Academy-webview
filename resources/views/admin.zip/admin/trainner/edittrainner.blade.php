@include('layout.header')
@include('layout.navbar')
@include('layout.sidebar')

<!-- Mirrored from koki.dexignzone.com/xhtml/page-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2022 06:08:47 GMT -->


<body class="h-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6" style="margin-top:9rem">
          
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
		
                                <form action="{{url('/updateuser')}}" method="post" enctype="multipart/form-data">

           @if(Session::has('success'))
        <div class="alert alert-success">{{ Session::get('success') }}</div>
        @endif
        @if(Session::has('fail'))
        <div class="alert alert-danger">{{ Session::get('fail') }}</div>
        @endif
        @csrf   
           <h3 style="color: #8f0acd;font-weight: bold;text-align: center;font-size: 29px;">Edit User</h3>  
       
                    <div class="mb-3 col-md-8">
                        <label>username</label>
                            <input type="text" class="form-control" name="username" value="@if (!empty($data)){{ $data->username }}@else{{ old('username') }}@endif">
                            </div>  
                         <div class="mb-3 col-md-8">
                        <label>email</label>
                            <input type="email" class="form-control" name="email" value="@if (!empty($data)){{ $data->email }}@else{{ old('email') }}@endif">
                            </div>  
                         <div class="mb-3 col-md-8">
                        <label>password</label>
                            <input type="password" class="form-control" name="password" value="@if (!empty($data)){{ $data->password }}@else{{ old('password') }}@endif">
                            </div>  
                       <div class="mb-3 col-md-8">
                        <label>address</label>
                            <input type="text" class="form-control" name="address" value="@if (!empty($data)){{ $data->address }}@else{{ old('address') }}@endif">
                            </div>  
                       <div class="mb-3 col-md-8">
                        <label>Mobile Number</label>
                            <input type="number" class="form-control" name="mobile" value="@if (!empty($data)){{ $data->mobile }}@else{{ old('mobile') }}@endif">
                            </div>  
                        </div>  
                                         
                      <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>  
                                    </form>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="{{asset('vendor/global/global.min.js')}}"></script>
    <script src="{{asset('js/custom.min.js')}}"></script>
    <script src="{{asset('js/deznav-init.js')}}"></script>

</body>


<!-- Mirrored from koki.dexignzone.com/xhtml/page-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 16 Mar 2022 06:08:48 GMT -->
</html>